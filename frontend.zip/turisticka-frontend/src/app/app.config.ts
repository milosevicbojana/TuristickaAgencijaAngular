import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { Auth } from './core/interceptors/auth-interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptorsFromDi()), //kaže HttpClient-u da interceptore traži u DI sistemu.
    {
      provide: HTTP_INTERCEPTORS, //je token pod kojim se registruju svi interceptori.
      useClass: Auth, //kaže koju klasu da napravi.
      multi: true //dodaje je na listu, umesto da zameni ostale. Da imaš još interceptora (npr. za logovanje grešaka), izvršavali bi se redom.
    }
  ]
};
