import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthService } from '../services/auth-service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Auth implements HttpInterceptor {

  constructor(private authService: AuthService) {} //DI ubacuje AuthService. Interceptor ga koristi samo da pročita token.

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token = this.authService.getToken(); //Čita token iz localStorage. Vraća null ako nije ulogovana.

    if (!token) {
      return next.handle(req);
    }

    const authReq = req.clone({
      headers: req.headers.set('Authorization', `Bearer ${token}`)
    });

    return next.handle(authReq);
  }
}