package com.example.demo.converter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class MyConverter implements Converter<String, Date> {
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    public Date convert(String source) {
        if (source == null || source.trim().isEmpty()) {
            return null; // ako nije popunjeno polje za datum
        }
        try {
            return dateFormat.parse(source);
        } catch (ParseException e) {
            throw new RuntimeException("Neispravan format datuma: " + source, e);
        }
    }
}
