<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Prijava</title>
<link rel="stylesheet"
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
	<c:if test="${not empty success}">
		<div class="alert alert-success">${success}</div>
	</c:if>

	<c:if test="${not empty error}">
		<div class="alert alert-danger">${error}</div>
	</c:if>
	<div class="container mt-5" style="max-width: 400px;">
		<h2 class="text-center mb-4">🔐 Prijavi se</h2>

		<form action="${pageContext.request.contextPath}/login" method="post">
			<div class="mb-3">
				<label class="form-label">Korisničko ime</label> 
				<input type="text" class="form-control" name="username" required>
			</div>

			<div class="mb-3">
				<label class="form-label">Lozinka</label> 
				<input type="password" class="form-control" name="password" required>
			</div>

			<button type="submit" class="btn btn-primary w-100">Prijavi se</button>
			<div class="text-center mt-3">
				<a href="${pageContext.request.contextPath}/index" class="btn btn-secondary"> Povratak na početnu </a>
			</div>

			<p class="mt-3 text-center">
				Nemaš nalog? <a href="${pageContext.request.contextPath}/korisnici/register">Registruj se</a>
			</p>
		</form>
	</div>
</body>
</html>