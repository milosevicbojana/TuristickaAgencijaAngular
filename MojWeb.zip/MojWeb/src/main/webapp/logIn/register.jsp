<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Registracija</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
	<div class="container mt-5" style="max-width: 400px;">
		<h2 class="text-center mb-4">🧾 Registracija</h2>

		<c:if test="${not empty error}">
			<div class="alert alert-danger">${error}</div>
		</c:if>

		<form:form modelAttribute="korisnik" action="${pageContext.request.contextPath}/korisnici/register1" method="post">

			<div class="mb-3">
				<label class="form-label">Korisničko ime</label>
				<form:input path="korisnickoIme" cssClass="form-control" />
				<form:errors path="korisnickoIme" cssClass="text-danger" />
			</div>

			<div class="mb-3">
				<label class="form-label">Email</label>
				<form:input path="email" cssClass="form-control" />
				<form:errors path="email" cssClass="text-danger" />
			</div>

			<div class="mb-3">
				<label class="form-label">Lozinka</label>
				<form:password path="lozinka" cssClass="form-control" />
				<form:errors path="lozinka" cssClass="text-danger" />
			</div>

			<div class="mb-3">
				<label class="form-label">Uloga</label>
				<form:select path="uloga" cssClass="form-select">
					<form:option value="" label="Izaberi ulogu" />
					<form:options items="${uloge}" itemValue="id" itemLabel="naziv" />
				</form:select>
				<form:errors path="uloga" cssClass="text-danger" />
			</div>

			<button type="submit" class="btn btn-success w-100">Registruj se</button>

			<div class="text-center mt-3">
				<a href="${pageContext.request.contextPath}/index" class="btn btn-secondary">Povratak na početnu </a>
			</div>

			<p class="mt-3 text-center">
				Već imaš nalog? <a href="${pageContext.request.contextPath}/korisnici/login">Prijavi se</a>
			</p>
			</form:form>
	</div>
</body>
</html>