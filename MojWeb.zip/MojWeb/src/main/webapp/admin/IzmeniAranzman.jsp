<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Izmeni Aranžman</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="container mt-5" style="max-width: 600px;">
    <div class="card shadow-sm">
        <div class="card-body">
            <h3 class="card-title text-center mb-4">✏️ Izmena aranžmana</h3>

            <form action="${pageContext.request.contextPath}/admin/sacuvajIzmeneAranzmana" method="post">
                <input type="hidden" name="id" value="${aranzman.id}" />

                <div class="mb-3">
                    <label class="form-label">Naziv</label>
                    <input type="text" name="naziv" class="form-control" value="${aranzman.naziv}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Opis</label>
                    <textarea name="opis" class="form-control" rows="4" required>${aranzman.opis}</textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Cena (RSD)</label>
                    <input type="number" step="0.01" name="cena" class="form-control" value="${aranzman.cena}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Slobodna mesta</label>
                    <input type="number" name="slobodnaMesta" class="form-control" value="${aranzman.slobodnaMesta}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Datum početka</label>
                    <input type="date" name="datumPocetka" class="form-control" value="${aranzman.datumPocetka}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Datum završetka</label>
                    <input type="date" name="datumZavrsetka" class="form-control" value="${aranzman.datumZavrsetka}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Kategorija</label>
                    <select name="kategorijaId" class="form-select" required>
                        <option value="">-- Izaberite kategoriju --</option>
                        <c:forEach var="kat" items="${kategorije}">
                            <option value="${kat.id}" ${aranzman.kategorija.id == kat.id ? 'selected' : ''}>${kat.naziv}</option>
                        </c:forEach>
                    </select>
                </div>

                <!-- Dugmad iste veličine -->
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-success">Sačuvaj izmene</button>
                    <a href="${pageContext.request.contextPath}/korisnici/admin" class="btn btn-secondary">Nazad na početnu</a>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>
