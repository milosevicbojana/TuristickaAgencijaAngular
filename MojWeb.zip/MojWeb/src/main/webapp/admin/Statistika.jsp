<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Statistika aranžmana</title>
<link rel="stylesheet"
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
	<div class="container mt-5">
		<h2 class="mb-4 text-center">📊 Statistika aranžmana</h2>

		<!-- 🔹 Tabela 1: Broj rezervacija po aranžmanu (poslednjih 30 dana) -->
		<h4 class="mt-4 mb-3">Broj rezervacija po aranžmanu (poslednjih 30 dana)</h4>
		<table class="table table-bordered table-striped">
			<thead class="table-dark">
				<tr>
					<th>Aranžman</th>
					<th>Broj rezervacija</th>
				</tr>
			</thead>
			<tbody>
				<c:forEach var="row" items="${rezervacijePoAranzmanu}">
					<tr>
						<td>${row[0]}</td>
						<td>${row[1]}</td>
					</tr>
				</c:forEach>
				<c:if test="${empty rezervacijePoAranzmanu}">
					<tr>
						<td colspan="2" class="text-center">Nema podataka za poslednjih 30 dana</td>
					</tr>
				</c:if>
			</tbody>
		</table>

		<!-- 🔹 Tabela 2: Prihodi po aranžmanu -->
		<h4 class="mt-5 mb-3">Prihodi po aranžmanu</h4>
		<table class="table table-bordered table-striped">
			<thead class="table-dark">
				<tr>
					<th>Aranžman</th>
					<th>Prihod (RSD)</th>
				</tr>
			</thead>
			<tbody>
				<c:forEach var="row" items="${prihodiPoAranzmanu}">
					<tr>
						<td>${row[0]}</td>
						<td>${row[1]}</td>
					</tr>
				</c:forEach>
				<c:if test="${empty prihodiPoAranzmanu}">
					<tr>
						<td colspan="2" class="text-center">Nema podataka</td>
					</tr>
				</c:if>
			</tbody>
		</table>

		<!-- 🔹 Dugme za povratak -->
		<div class="mt-4 text-center">
			<a href="${pageContext.request.contextPath}/korisnici/admin" class="btn btn-secondary">Nazad na početnu</a>
		</div>
	</div>
</body>
</html>
