<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Pregled rezervacija</title>
<link rel="stylesheet"
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
	<div class="container mt-4">
		<div class="d-flex justify-content-between align-items-center mb-3">
			<h2>Pregled rezervacija</h2>
			<a href="${pageContext.request.contextPath}/korisnici/admin" class="btn btn-secondary">Nazad na početnu</a>
		</div>

		<form
			action="${pageContext.request.contextPath}/admin/rezervacije/filter"
			method="get" class="mb-3 d-flex gap-2">
			<select name="aranzmanId" class="form-select w-auto">
				<option value="">-- Svi aranžmani --</option>
				<c:forEach var="a" items="${aranzmani}">
					<option value="${a.id}" <c:if test="${selectedAranzmanId == a.id}">selected</c:if>>
						${a.naziv}</option>
				</c:forEach>
			</select>

			<button type="submit" class="btn btn-success">Filtriraj</button>
			<a href="${pageContext.request.contextPath}/admin/rezervacije"
				class="btn btn-secondary">Reset</a>
			<c:if test="${not empty rezervacije && selectedAranzmanId != null}">
				<button type="submit" class="btn btn-primary"
					formaction="${pageContext.request.contextPath}/admin/izvestaj/aranzman/${selectedAranzmanId}"
					formtarget="_blank">Generiši izveštaj</button>
			</c:if>
		</form>

		<c:if test="${not empty rezervacije}">
			<table
				class="table table-bordered table-striped align-middle text-start">
				<thead class="table-dark">
					<tr>
						<th>Korisnik</th>
						<th>Aranžman</th>
						<th>Broj osoba</th>
						<th>Ukupna cena (RSD)</th>
						<!-- NOVA KOLONA -->
						<th>Datum rezervacije</th>
						<th>Status</th>
						<th style="width: 140px;">Akcije</th>
					</tr>
				</thead>
				<tbody>
					<c:forEach var="r" items="${rezervacije}">
						<tr>
							<td>${r.korisnik.korisnickoIme}</td>
							<td>${r.aranzman.naziv}</td>
							<td>${r.brojOsoba}</td>

							<!-- NOVA KOLONA: Ukupna cena formatirana na dve decimale -->
							<td><fmt:formatNumber value="${r.ukupnaCena}" type="number"
									minFractionDigits="2" groupingUsed="false" /></td>

							<td><fmt:formatDate value="${r.datumRezervacije}"
									pattern="dd.MM.yyyy HH:mm" /></td>
							<td>${r.status}</td>

							<td><c:choose>
									<c:when test="${r.status == 'NA CEKANJU'}">
										<form
											action="${pageContext.request.contextPath}/admin/rezervacije/status/${r.id}"
											method="post" class="d-flex justify-content-start gap-1">
											<button type="submit" name="status" value="ODOBRENO"
												class="btn btn-success btn-sm px-2 py-1">Odobri</button>
											<button type="submit" name="status" value="ODBIJENO"
												class="btn btn-danger btn-sm px-2 py-1">Odbij</button>
										</form>
									</c:when>

									<c:otherwise>
										<c:choose>
											<c:when test="${r.status == 'ODBIJENO'}">
												<form
													action="${pageContext.request.contextPath}/admin/rezervacije/obrisi/${r.id}"
													method="post" class="d-flex justify-content-start">
													<button type="submit"
														class="btn btn-danger btn-sm px-2 py-1"
														onclick="return confirm('Da li ste sigurni da želite da obrišete ovu rezervaciju?');">
														Obriši</button>
												</form>
											</c:when>
											<c:otherwise>
												<form
													action="${pageContext.request.contextPath}/admin/rezervacije/otkazi/${r.id}"
													method="post" class="d-flex justify-content-start">
													<button type="submit"
														class="btn btn-warning btn-sm px-2 py-1"
														onclick="return confirm('Da li ste sigurni da želite da otkažete ovu rezervaciju?');">
														Otkaži</button>
												</form>
											</c:otherwise>
										</c:choose>
									</c:otherwise>
								</c:choose></td>
						</tr>
					</c:forEach>
				</tbody>
			</table>
		</c:if>

		<c:if test="${empty rezervacije}">
			<div class="alert alert-warning text-center mt-3">Trenutno nema rezervacija.</div>
		</c:if>
	</div>
</body>
</html>
