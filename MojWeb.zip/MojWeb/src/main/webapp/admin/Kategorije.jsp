<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Upravljanje kategorijama</title>
<link rel="stylesheet"
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
	<div class="container mt-4">
		<div class="d-flex justify-content-between align-items-center mb-3">
			<h2>Upravljanje kategorijama</h2>
			<a href="${pageContext.request.contextPath}/korisnici/admin"
				class="btn btn-secondary">Nazad na početnu</a>
		</div>

		<form
			action="${pageContext.request.contextPath}/admin/sacuvajKategoriju"
			method="post" class="mb-3 d-flex">
			<input type="text" name="naziv" class="form-control me-2"
				placeholder="Unesite naziv kategorije" required>
			<button type="submit" class="btn btn-success"
				style="white-space: nowrap;">➕ Dodaj novu kategoriju</button>
		</form>

		<c:if test="${not empty poruka}">
			<div class="alert alert-info">${poruka}</div>
		</c:if>

		<table class="table table-bordered table-striped">
			<thead class="table-dark">
				<tr>
					<th>Naziv</th>
					<th style="width: 160px;">Akcije</th>
				</tr>
			</thead>
			<tbody>
				<c:forEach var="k" items="${kategorije}">
					<tr>
						<td><c:if test="${editId == k.id}">
								<form
									action="${pageContext.request.contextPath}/admin/sacuvajKategoriju"
									method="post" class="d-flex">
									<input type="hidden" name="id" value="${k.id}" /> <input
										type="text" name="naziv" class="form-control me-2"
										value="${k.naziv}" required />
									<button type="submit" class="btn btn-success btn-sm me-2">Sačuvaj</button>
									<a href="${pageContext.request.contextPath}/admin/kategorije"
										class="btn btn-secondary btn-sm">Otkaži</a>
								</form>
							</c:if> <c:if test="${editId != k.id}">
                        ${k.naziv}
                    </c:if></td>
						<td class="text-center" style="width: 160px;"><c:if
								test="${editId != k.id}">
								<a
									href="${pageContext.request.contextPath}/admin/kategorije?editId=${k.id}"
									class="btn btn-warning btn-sm me-2">Izmeni</a>
								<a
									href="${pageContext.request.contextPath}/admin/obrisiKategoriju/${k.id}"
									class="btn btn-danger btn-sm"
									onclick="return confirm('Da li ste sigurni da želite da obrišete ovu kategoriju?');">Obriši</a>
							</c:if></td>
					</tr>
				</c:forEach>
			</tbody>
		</table>
	</div>
</body>
</html>
