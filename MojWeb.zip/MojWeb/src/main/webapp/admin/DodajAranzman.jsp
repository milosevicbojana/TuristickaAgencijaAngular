<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dodaj Aranžman</title>
<link rel="stylesheet"
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
	<div class="container mt-5" style="max-width: 600px;">
		<div class="card shadow-sm">
			<div class="card-body">
				<h3 class="card-title text-center mb-4">➕ Dodavanje novog aranžmana</h3>
				<form:form action="${pageContext.request.contextPath}/admin/sacuvajAranzman" method="post" modelAttribute="aranzman">
					<div class="mb-3">
						<label class="form-label">Naziv</label>
						<form:input path="naziv" cssClass="form-control" />
						<form:errors path="naziv" cssClass="text-danger" />
					</div>

					<!-- Opis -->
					<div class="mb-3">
						<label class="form-label">Opis</label>
						<form:textarea path="opis" cssClass="form-control" rows="4" />
						<form:errors path="opis" cssClass="text-danger" />
					</div>
					<div class="mb-3">
						<label class="form-label">Slobodna mesta</label>
						<form:input path="slobodnaMesta" type="number" class="form-control" />
						<form:errors path="slobodnaMesta" cssClass="text-danger" />
					</div>
					<div class="mb-3">
						<label class="form-label">Cena (RSD)</label>
						<form:input path="cena" type="number" step="0.01" class="form-control" />
						<form:errors path="cena" cssClass="text-danger" />
					</div>
					<div class="mb-3">
						<label class="form-label">Datum početka</label>
						<form:input path="datumPocetka" type="date" class="form-control" />
						<form:errors path="datumPocetka" cssClass="text-danger" />
					</div>
					<div class="mb-3">
						<label class="form-label">Datum završetka</label>
						<form:input path="datumZavrsetka" type="date" class="form-control" />
						<form:errors path="datumZavrsetka" cssClass="text-danger" />
					</div>
					<div class="mb-3">
						<label class="form-label">Kategorija</label>
						<form:select path="kategorija" class="form-select">
							<form:option value="">-- Izaberite kategoriju --</form:option>
							<form:options items="${kategorije}" itemValue="id" itemLabel="naziv" />
						</form:select>
						<form:errors path="kategorija" cssClass="text-danger" />
					</div>
					<div class="d-grid gap-2">
						<button type="submit" class="btn btn-success">Sačuvaj aranžman</button>
					</div>
				</form:form>
				<div class="text-center mt-3">
					<a href="${pageContext.request.contextPath}/korisnici/admin"
						class="btn btn-secondary">Nazad na početnu</a>
				</div>
			</div>
		</div>
	</div>
</body>
</html>