<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Moje rezervacije</title>
<link rel="stylesheet"
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
	<div class="container mt-5">

		<div class="d-flex justify-content-between align-items-center mb-4">
			<h1 class="text-center mb-0">📝 Moje rezervacije</h1>
			<div>
				<a href="${pageContext.request.contextPath}/korisnici/user" class="btn btn-secondary me-2">Povratak</a> 
				<a href="${pageContext.request.contextPath}/korisnici/logout" class="btn btn-danger me-2">Odjavi se</a>
			</div>
		</div>

		<c:if test="${empty rezervacije}">
			<div class="alert alert-warning text-center">Nemate rezervacija.</div>
		</c:if>

		<c:if test="${not empty rezervacije}">
			<div class="list-group">
				<c:forEach var="r" items="${rezervacije}">
					<div
						class="list-group-item d-flex justify-content-between align-items-center">
						<div>
							<strong>Aranžman:</strong> ${r.aranzman.naziv}<br> 
							<strong>Datum:</strong> ${r.aranzman.datumPocetka} - ${r.aranzman.datumZavrsetka}<br> 
							<strong>Cena:</strong> ${r.ukupnaCena} RSD<br> 
							<strong>Broj rezervisanih mesta:</strong> ${r.brojOsoba}<br>

							<c:choose>
								<c:when test="${r.status == 'ODOBRENO'}">
									<span class="text-success">Status: ${r.status}</span>
								</c:when>
								<c:when test="${r.status == 'ODBIJENO'}">
									<span class="text-danger">Status: ${r.status}</span>
								</c:when>
								<c:when test="${r.status == 'NA CEKANJU'}">
									<span class="text-warning">Status: ${r.status}</span>
								</c:when>
							</c:choose>
						</div>
						<div class="d-flex gap-2">
							<c:if test="${r.status == 'ODOBRENO'}">
								<a href="${pageContext.request.contextPath}/korisnikRez/izvestaj/rezervacija/${r.id}"
									target="_blank" class="btn btn-primary btn-sm">Generiši izveštaj</a>
							</c:if>

							<form action="${pageContext.request.contextPath}/korisnikRez/otkaziRezervaciju/${r.id}" method="post">
								<button type="submit" class="btn btn-danger btn-sm">Otkaži</button>
							</form>
						</div>
					</div>
				</c:forEach>
			</div>
		</c:if>

	</div>
</body>
</html>
