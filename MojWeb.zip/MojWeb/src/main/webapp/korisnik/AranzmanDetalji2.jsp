<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Detalji aranžmana</title>
<link rel="stylesheet"
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

	<div class="container mt-5">

		<c:if test="${param.success eq 'ok'}">
			<div class="alert alert-success text-center">Komentar i ocena
				su uspešno dodati!</div>
		</c:if>

		<!-- Naslov -->
		<h1 class="text-center mb-4">Detalji aranžmana</h1>

		<!-- Kartica sa detaljima, komentarima i ocenama -->
		<div class="card shadow-sm mb-4">
			<div class="card-body">
				<!-- Osnovni podaci aranžmana -->
				<h3 class="card-title">${aranzman.naziv}</h3>
				<p class="card-text mb-2">
					<strong>Opis:</strong> ${aranzman.opis}<br> <strong>Datum:</strong>
					${aranzman.datumPocetka} - ${aranzman.datumZavrsetka}<br> <strong>Cena:</strong>
					${aranzman.cena} RSD<br> <strong>Slobodna mesta:</strong>
					${aranzman.slobodnaMesta}<br> <strong>Kategorija:</strong>
					${aranzman.kategorija.naziv}
				</p>

				<!-- Komentari -->
				<h5 class="mt-4">Komentari korisnika</h5>
				<!-- mt-4 daje veći razmak od prethodnog sadržaja -->
				<c:if test="${empty aranzman.komentars}">
					<div class="alert alert-warning">Nema komentara za ovaj aranžman.</div>
				</c:if>
				<c:forEach var="k" items="${aranzman.komentars}">
					<div class="border rounded p-2 mb-2">
						<p class="mb-1">
							<strong>${k.korisnik.korisnickoIme}:</strong> ${k.sadrzaj}
						</p>
						<small class="text-muted">${k.datumKreiranja}</small>
					</div>
				</c:forEach>

				<!-- Ocene -->
				<h5 class="mt-4">Ocene korisnika</h5>
				<!-- mt-4 daje veći razmak -->
				<c:if test="${empty aranzman.ocenas}">
					<div class="alert alert-warning">Nema ocena za ovaj aranžman.</div>
				</c:if>
				<c:forEach var="o" items="${aranzman.ocenas}">
					<div class="border rounded p-2 mb-2">
						<p class="mb-0">
							<strong>${o.korisnik.korisnickoIme}:</strong> ${o.vrednost} / 5
						</p>
					</div>
				</c:forEach>

				<!-- Forma za dodavanje komentara i ocene -->
				<h5 class="mt-4">Dodaj komentar i ocenu</h5>
				<form
					action="${pageContext.request.contextPath}/korisnik/dodajKomentarOcenu/${aranzman.id}"
					method="post">
					<div class="mb-3">
						<label for="sadrzaj" class="form-label">Komentar</label>
						<textarea class="form-control" id="sadrzaj" name="sadrzaj"
							rows="3" required></textarea>
					</div>
					<div class="mb-3">
						<label for="ocena" class="form-label">Ocena</label> <select
							class="form-select" id="ocena" name="vrednost" required>
							<option value="">Izaberite ocenu</option>
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="3">3</option>
							<option value="4">4</option>
							<option value="5">5</option>
						</select>
					</div>
					<button type="submit" class="btn btn-success">Pošalji</button>
				</form>

			</div>
			<!-- kraj card-body -->
		</div>
		<!-- kraj kartice -->

		<!-- Dugmad ispod cele kartice -->
		<div class="d-flex justify-content-between mb-4">
			<a href="${pageContext.request.contextPath}/korisnici/user"
				class="btn btn-secondary">Nazad</a>

			<form
				action="${pageContext.request.contextPath}/korisnik/rezervisi/${aranzman.id}"
				method="post" class="d-flex align-items-center">

				<div class="me-2">
					<label for="brojMesta" class="form-label">Broj mesta:</label> 
					<input type="number" id="brojMesta" name="brojMesta" class="form-control" min="1" max="${aranzman.slobodnaMesta}" value="1" required>
				</div>

				<button type="submit" class="btn btn-success mt-4"
					${aranzman.slobodnaMesta == 0 ? 'disabled' : ''}>Rezerviši</button>
			</form>
		</div>

	</div>

</body>
</html>
