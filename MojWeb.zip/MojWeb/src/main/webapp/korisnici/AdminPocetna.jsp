<%@ page contentType="text/html;charset=UTF-8" language="java"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<html>
<head>
<title>Admin početna</title>
<link rel="stylesheet"
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
	<div class="container mt-4">
		<div class="d-flex justify-content-between align-items-center mb-3">
			<h2>Dobrodošli, admin!</h2>
			<a href="${pageContext.request.contextPath}/korisnici/logout"
				class="btn btn-danger">Odjavi se</a>
		</div>

		<div class="d-flex gap-2 mb-3">
			<a href="${pageContext.request.contextPath}/dodajAranzman" class="btn btn-success">➕ Dodaj novi aranžman</a> 
			<a href="${pageContext.request.contextPath}/admin/kategorije" class="btn btn-success">📂 Pregled kategorija</a>
			<a href="${pageContext.request.contextPath}/admin/rezervacije" class="btn btn-success">📝 Pregled rezervacija</a> 
			<a href="${pageContext.request.contextPath}/admin/statistika/statistika" class="btn btn-success">📊 Statistika</a>
		</div>

		<div class="mb-3">
			<form action="${pageContext.request.contextPath}/filter" method="get"
				class="row g-2 align-items-end">

				<!-- hidden input za tip stranice -->
				<input type="hidden" name="tipStranice" value="admin" />

				<!-- Naziv aranžmana -->
				<div class="col-lg">
					<input type="text" name="naziv" class="form-control"
						placeholder="Naziv aranžmana"
						value="${filterNaziv != null ? filterNaziv : ''}">
				</div>

				<!-- Kategorija -->
				<div class="col-lg">
					<select name="kategorijaId" class="form-select">
						<option value="">Sve kategorije</option>
						<c:forEach var="kat" items="${kategorije}">
							<option value="${kat.id}"
								${kat.id == filterKategorijaId ? 'selected' : ''}>
								${kat.naziv}</option>
						</c:forEach>
					</select>
				</div>

				<!-- Datum od -->
				<div class="col-lg">
					<input type="date" name="datumOd" class="form-control"
						value="${filterDatumOd != null ? filterDatumOd : ''}">
				</div>

				<!-- Datum do -->
				<div class="col-lg">
					<input type="date" name="datumDo" class="form-control"
						value="${filterDatumDo != null ? filterDatumDo : ''}">
				</div>

				<!-- Cena od -->
				<div class="col-lg">
					<input type="number" step="0.01" name="cenaOd" class="form-control"
						placeholder="Cena od"
						value="${filterCenaOd != null ? filterCenaOd : ''}">
				</div>

				<!-- Cena do -->
				<div class="col-lg">
					<input type="number" step="0.01" name="cenaDo" class="form-control"
						placeholder="Cena do"
						value="${filterCenaDo != null ? filterCenaDo : ''}">
				</div>

				<!-- Dugmad -->
				<div class="col-lg d-flex gap-2">
					<button type="submit" class="btn btn-success flex-grow-1">Filtriraj</button>
					<a href="${pageContext.request.contextPath}/korisnici/admin"
						class="btn btn-secondary flex-grow-1">Reset</a>
				</div>
			</form>
		</div>
		<c:if test = "${not empty aranzmani}">
			<table class="table table-bordered table-striped">
				<thead class="table-dark">
					<tr>
						<th>Naziv</th>
						<th>Opis</th>
						<th>Cena</th>
						<th>Kategorija</th>
						<!-- nova kolona -->
						<th>Akcije</th>
					</tr>
				</thead>
				<tbody>
					<c:forEach var="a" items="${aranzmani}">
						<tr>
							<td>${a.naziv}</td>
							<td>${a.opis}</td>
							<td>${a.cena}RSD</td>
							<td>${a.kategorija != null ? a.kategorija.naziv : ''}</td>
							<!-- nova kolona -->
							<td><a
								href="${pageContext.request.contextPath}/admin/izmeniAranzman/${a.id}"
								class="btn btn-warning btn-sm">Izmeni</a> <a
								href="${pageContext.request.contextPath}/admin/obrisiAranzman/${a.id}"
								class="btn btn-danger btn-sm"
								onclick="return confirm('Da li ste sigurni da želite da obrišete ovaj aranžman?');">
									Obriši </a></td>
						</tr>
					</c:forEach>
				</tbody>
			</table>
		</c:if>
		<c:if test="${empty aranzmani}">
			<div class="alert alert-warning text-center mt-3">Nema rezultata za zadati filter.</div>
		</c:if>
	</div>
</body>
</html>
