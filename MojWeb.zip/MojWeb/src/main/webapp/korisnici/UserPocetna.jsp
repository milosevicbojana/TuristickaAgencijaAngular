<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Korisnička početna</title>
<link rel="stylesheet"
	href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

	<div class="container mt-5">

		<c:if test="${param.success eq 'ok'}">
			<div class="alert alert-success text-center">Rezervacija je uspešno izvršena!</div>
		</c:if>

		<c:if test="${param.error eq 'noSeats'}">
			<div class="alert alert-danger text-center">Nema slobodnih mesta za ovaj aranžman!</div>
		</c:if>

		<!-- Naslov i dugme odjavi se -->
		<div class="d-flex justify-content-between align-items-center mb-4">
			<h1 class="text-center mb-0">🏝️ Putnički aranžmani</h1>
			<div>
				<a href="${pageContext.request.contextPath}/korisnikRez/rezervacije" class="btn btn-success me-2">Pregled Rezervacija</a> 
				<a href="${pageContext.request.contextPath}/korisnici/logout" class="btn btn-danger">Odjavi se</a>
			</div>
		</div>

		<!-- Filter forma -->
		<div class="mb-3">
			<form action="${pageContext.request.contextPath}/filter" method="get" class="row g-2 align-items-end">

				<!-- hidden input za tip stranice -->
				<input type="hidden" name="tipStranice" value="user" />

				<!-- Naziv aranžmana -->
				<div class="col-lg">
					<input type="text" name="naziv" class="form-control" placeholder="Naziv aranžmana" value="${filterNaziv != null ? filterNaziv : ''}">
				</div>

				<!-- Kategorija -->
				<div class="col-lg">
					<select name="kategorijaId" class="form-select">
						<option value="">Sve kategorije</option>
						<c:forEach var="kat" items="${kategorije}">
							<option value="${kat.id}"
								${kat.id == filterKategorijaId ? 'selected' : ''}>
								${kat.naziv}</option>
						</c:forEach>
					</select>
				</div>

				<!-- Datum od -->
				<div class="col-lg">
					<input type="date" name="datumOd" class="form-control" value="${filterDatumOd != null ? filterDatumOd : ''}">
				</div>

				<!-- Datum do -->
				<div class="col-lg">
					<input type="date" name="datumDo" class="form-control" value="${filterDatumDo != null ? filterDatumDo : ''}">
				</div>

				<!-- Cena od -->
				<div class="col-lg">
					<input type="number" step="0.01" name="cenaOd" class="form-control" placeholder="Cena od" value="${filterCenaOd != null ? filterCenaOd : ''}">
				</div>

				<!-- Cena do -->
				<div class="col-lg">
					<input type="number" step="0.01" name="cenaDo" class="form-control" placeholder="Cena do" value="${filterCenaDo != null ? filterCenaDo : ''}">
				</div>

				<!-- Dugmad -->
				<div class="col-lg d-flex gap-2">
					<button type="submit" class="btn btn-success flex-grow-1">Filtriraj</button>
					<a href="${pageContext.request.contextPath}/korisnici/user" class="btn btn-secondary flex-grow-1">Reset</a>
				</div>
			</form>
		</div>

		<!-- Lista aranžmana -->
		<div class="row">
			<c:if test="${empty aranzmani}">
				<div class="col-12">
					<div class="alert alert-warning text-center">Nema rezultata za zadati filter.</div>
				</div>
			</c:if>

			<c:forEach var="a" items="${aranzmani}">
				<div class="col-md-4 mb-4">
					<div class="card shadow-sm h-100">
						<div
							class="card-body d-flex flex-column justify-content-between h-100">
							<div class="mb-3">
								<h5 class="card-title">${a.naziv}</h5>
								<p class="card-text">
									<strong>Opis:</strong> ${a.opis}<br> <strong>Datum:</strong>
									${a.datumPocetka} - ${a.datumZavrsetka}<br> <strong>Cena:</strong>
									${a.cena} RSD<br> <strong>Slobodna mesta:</strong>
									${a.slobodnaMesta}
								</p>
							</div>

							<div class="mt-auto">
								<a href="${pageContext.request.contextPath}/aranzman/${a.id}" class="btn btn-success w-100">Detaljnije</a>
							</div>
						</div>
					</div>
				</div>
			</c:forEach>
		</div>
	</div>

</body>
</html>
